<?php include("header.php")?>
<body>
	<?php include("navbar.php")?>
	<style type="text/css">
		.conatiner{
			margin-top: 3%;
			margin-left: 10%;
			margin-right: 10%;
		}
		#show{
			width: 100%;
		}
		#add{
			margin-top: 5%;
			width: 100%;
		}
    #show2{
      margin-top: 5%;
      margin-bottom: 5%;
      width: 100%;
    }
    .conatiner{

      font-size: 13px;
    }

	</style>
	<div class="conatiner">
    <button type="button" class="btn btn-primary" id="show2" data-bs-toggle="modal" data-bs-target="#exampleModal3">
  Accepted Payments
</button>
		<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" id="show" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Show Payments
</button>

		<!-- Button trigger modal -->
<button type="button" id="add" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Add Payments
</button>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Add Payments</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="title" class="form-control" />
    <label class="form-label" for="form6Example3">Payment Tittle</label>
  </div>
  
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="receiver" class="form-control" />
    <label class="form-label" for="form6Example3">Reciever (Client Name)</label>
  </div>
  
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="other" class="form-control" />
    <label class="form-label" for="form6Example3">Other Details (Client )</label>
  </div>


  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="total_amount" class="form-control" />
    <label class="form-label" for="form6Example3">Total Amount</label>
  </div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="advance" class="form-control" />
    <label class="form-label" for="form6Example4">Advance Amount</label>
  </div>

  <div class="form-floating">
  <select class="form-select" id="status" aria-label="Floating label select example">
    <option value="success">Success</option>
    <option value="pending">Pending</option>
  </select>
  <label for="floatingSelect">Works with selects</label>
</div>

  <!-- Email input -->
  <div data-mdb-input-init class="form-outline mb-4 mt-4">
    <input type="date" id="date" class="form-control" />
    <!-- <label class="form-label" for="form6Example5">Date</label> -->
  </div>

  <!-- Number input -->
  <!-- <div data-mdb-input-init class="form-outline mb-4">
    <input type="number" id="form6Example6" class="form-control" />
    <label class="form-label" for="form6Example6">Phone</label>
  </div> -->
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Button trigger modal -->
     <div id="payments"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Button trigger modal -->
     <div id="accepted-payments"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
		
	</div>
	<?php
// Assuming $id is defined earlier in your PHP code
echo "<script>var id = '" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "';</script>";
?>
</body>
<script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
    var submitButton = document.getElementById("submit");

    if (submitButton) {
        submitButton.addEventListener("click", function() {
            var title = document.getElementById("title").value;
            var total_amount = document.getElementById("total_amount").value;
            var advance = document.getElementById("advance").value;
            var status = document.getElementById("status").value;
            var date = document.getElementById("date").value;
            var client = document.getElementById("other").value;
            var receiver = document.getElementById("receiver").value;

            var obj = {
                title: title,
                total_amount: total_amount,
                advance: advance,
                status: status,
                date: date,
                client: client,
                receiver: receiver,
                id: id
            };

            fetch("fetch-data/submit-payment.php", {
                method: "POST",
                body: JSON.stringify(obj),
                headers: {
                    "Content-Type": "application/json"
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.data === "success") {
                    window.location.href = "payment.php";
                } else {
                    console.error("Error:", data.message);
                    alert("Error: " + data.message);
                }
            })
            .catch(error => {
                console.error("Fetch error:", error);
                alert("Fetch error: " + error.message);
            });
        });
    } else {
        console.error("Submit button not found");
    }
});
</script>
<script type="text/javascript">
  fetch("fetch-data/fetch-payments.php")
  .then(response=>response.text())
    .then((data)=>{
      document.getElementById("payments").innerHTML = data;
    })

</script>
<script type="text/javascript">
  fetch("fetch-data/accepted-payments.php")
  .then(response=>response.text())
    .then((data)=>{
      document.getElementById("accepted-payments").innerHTML = data;
    })

</script>
<script type="text/javascript">
   document.getElementById("searche").addEventListener("keyup", function () {
    var value = document.getElementById("searche").value;
    fetch("fetch-data/search-payments.php", {
        method: "POST",
        body: JSON.stringify({ value: value }),
        headers: {
            "Content-Type": "application/json"
        }
    }).then(response => response.text()) // Change to response.text() if the response is HTML
    .then((data) => {
        document.getElementById("container").innerHTML = data;
    }).catch((error) => {
        console.error('Error:', error);
    });
});
</script>