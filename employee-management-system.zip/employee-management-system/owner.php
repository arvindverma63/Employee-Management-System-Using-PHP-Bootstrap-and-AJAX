<?php include("header.php")?>

	<?php include("navbar.php")?>
	
	<style type="text/css">
		.contain{
			margin-left: 10%;
			margin-right: 10%;
			margin-top: 8%;
			display: flex;
			flex-direction: row;
		}
		#image1{
			height: 200px;
	        width: 200px;
	        margin-left: 5%;
		}
		#image2{
			height: 200px;
	        width: 200px;
		}
		@media (max-width: 700px){
			.contain{
				flex-direction: column;
				margin-top: 6%;
			}
		}
	</style>

	<div class="contain" id="contain">
		
	</div>
</body>
<script type="text/javascript">
	fetch("fetch-data/owner-index.php")
	.then(response=>response.text())
	.then((data)=>{
		document.getElementById("contain").innerHTML = data;
	})
</script>
</html>