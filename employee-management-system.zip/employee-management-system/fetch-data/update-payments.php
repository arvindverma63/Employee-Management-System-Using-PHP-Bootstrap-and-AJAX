<?php
include("../database/config.php");

// Get the input data
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Extract data
$id = $data["booking_id"];
$title = $data["title"];
$total_amount = $data["total_amount"];
$advance = $data["advance"];
$status = $data["status"];
$date = date("d-m-Y"); // Correct date format

// Use prepared statements to prevent SQL injection
if ($stmt = $conn->prepare("INSERT INTO update_bookings (`title`, `total_amount`, `advance`, `status`, `date`, `booking_id`) VALUES (?, ?, ?, ?, ?, ?)")) {
    $stmt->bind_param("ssssss", $title, $total_amount, $advance, $status, $date, $id);
    
    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode(["message" => "Booking added successfully"]);
    } else {
        echo json_encode(["error" => "Failed to add booking"]);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(["error" => "Failed to prepare the statement"]);
}

// Close the database connection
$conn->close();
?>
