<?php
// Include the database configuration file
include("../database/config.php");

// Get the JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

$response = array();

// Check if all required fields are present
if(isset($data["details"], $data["total_amount"], $data["advance"], $data["date"], $data["status"], $data["other"], $data["title"])) {
    // Extract data from JSON
    $detail = mysqli_real_escape_string($conn, $data["details"]);
    $total_amount = mysqli_real_escape_string($conn, $data["total_amount"]);
    $advance = mysqli_real_escape_string($conn, $data["advance"]);
    $date = mysqli_real_escape_string($conn, $data["date"]);
    $status = mysqli_real_escape_string($conn, $data["status"]);
    $other = mysqli_real_escape_string($conn, $data["other"]);
    $title = mysqli_real_escape_string($conn, $data["title"]);
    $booking_id = "B".time();

    // Prepare the SQL query using prepared statements
    $query = "INSERT INTO bookings(`title`,`details`,`total_amount`,`advance`,`date`,`status`,`other`,`booking_id`) VALUES(?,?,?,?,?,?,?,?)";
    $stmt = mysqli_prepare($conn, $query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, 'ssssssss', $title, $detail, $total_amount, $advance, $date, $status, $other,$booking_id);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    // Check if the query was successful
    if ($result) {
        $response = array("data" => "success");
    } else {
        $response = array("data" => "error", "message" => mysqli_error($conn));
    }
} else {
    $response = array("data" => "error", "message" => "Missing required fields");
}

// Return JSON response
echo json_encode($response);
?>
