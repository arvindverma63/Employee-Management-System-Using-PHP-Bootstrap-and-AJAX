<?php 
include("../database/config.php");

// Function to generate card HTML
function generateCard($row) {
    return '<div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <div class="ms-3">
                        <p class="fw-bold mb-1">Payment Tittle: ' . htmlspecialchars($row["title"]) . '</p>
                        <p class="fw-bold mb-1">Payment Status: ' . htmlspecialchars($row["status"]) . '</p>
                        <p class="text-muted mb-0">total_amount: ' . htmlspecialchars($row["total_amount"]) . '</p>
                        <p class="fw-bold mb-1"><i class="fas fa-user"></i>  Advance:  ' . htmlspecialchars($row["advance"]) . '</p>
                    </div>
                </div>
                <span class="badge rounded-pill badge-success">' . htmlspecialchars($row["date"]) . '</span>
            </div>
        </div>
    </div><hr>';
}

// Function to fetch and display bookings
function displayBookings($conn, $query) {
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo generateCard($row);
            }
        } else {
            echo "<center>No Booking Now</center>";
        }
    } else {
        echo "<center>Error fetching data</center>";
    }
}

// Queries
$query1 = "SELECT * FROM bookings ORDER BY s_no DESC";
$query2 = "SELECT * FROM update_bookings ORDER BY s_no DESC";

// Display bookings
displayBookings($conn, $query1);
displayBookings($conn, $query2);

mysqli_close($conn);
?>
