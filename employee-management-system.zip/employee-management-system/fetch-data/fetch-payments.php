<?php
include("../database/config.php");

// Fetch all payments
$query = "SELECT * FROM payments";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Fetch sender details using a prepared statement
        $stmt = mysqli_prepare($conn, "SELECT * FROM user_details WHERE u_id = ?");
        mysqli_stmt_bind_param($stmt, 's', $row["sender"]);
        mysqli_stmt_execute($stmt);
        $result2 = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result2) > 0) {
            $sender = mysqli_fetch_assoc($result2);
            $senderName = $sender["fname"] . " " . $sender["lname"];
        } else {
            $senderName = "Unknown Sender";
        }

        // Display the payment details along with sender's name
        if($row["request"] == ""){
            echo '
            <div class="form-outline" data-mdb-input-init>
  <input type="text" id="searche" class="form-control" />
  <label class="form-label" for="form12">search</label>
</div>
            <div class="card">
                <div class="card-header">PAYMENT REQUEST FROM ' . htmlspecialchars($row["client"], ENT_QUOTES, 'UTF-8') . ' </div>
                <div class="card-body">
                    
                    <h5 class="card-title">Amount: ' . htmlspecialchars($row["amount"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Advance Amount: ' . htmlspecialchars($row["advance"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Sender Name: ' . htmlspecialchars($senderName, ENT_QUOTES, 'UTF-8') . '</h5>
                    <a href="fetch-data/update-request.php?s_no='.$row["s_no"].'" class="btn btn-success" data-mdb-ripple-init> Click to Accept Request</a>
                    <h5 class="card-title mt-2">Date: ' . htmlspecialchars($row["date"], ENT_QUOTES, 'UTF-8') . '</h5>
                </div>
              </div><hr>';
        }

        mysqli_stmt_close($stmt);
    }
} else {
    echo "<center>No Payments Now</center>";
}

mysqli_close($conn);
?>
