<?php
    error_reporting(0);
    include('../database/config.php');
    if(isset($_SESSION['uid'])){

        $userId = $_SESSION['uid'];
        $sql = 'SELECT `role` FROM `users` WHERE `users`.`u_id`=? ;';

        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $userId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $row = mysqli_fetch_assoc($result);
        if($row['role'] == 'owner'){

        }
        elseif ($row['role'] == 'employee') {
            // code...
        }
        elseif($row['role'] == 'shop'){

        }
        else{
            include('fetch-data/logout.php');
            header("Location: ../index.php");
            exit();
        }

    }
?>
