<?php
include("../database/config.php");

$response = array();
$id = $_POST['id'];

$file_name = $_FILES['image']['name'];
$tempname = $_FILES['image']['tmp_name'];
$folder = "upload/".$file_name;

// Move the uploaded file to the desired location
move_uploaded_file($tempname, $folder);

$query = "UPDATE user_details SET image = '$folder' WHERE u_id = '$id'";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
    $response['data'] = "success"; // Add missing semicolon
} else {
    $response['data'] = "error"; // Optionally handle error response
}

// Return response as JSON
echo json_encode($response);
?>
