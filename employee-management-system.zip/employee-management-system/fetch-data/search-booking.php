<?php
include("../database/config.php");

// Get the raw input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Check for JSON decoding errors
if (json_last_error() !== JSON_ERROR_NONE) {
    echo 'Invalid JSON input';
    exit;
}

// Check if the value key exists in the data array
if (!isset($data['value'])) {
    echo 'Value key missing in input';
    exit;
}

$value = $data['value'];

// Use prepared statements to prevent SQL injection
$query = "SELECT * FROM bookings WHERE title LIKE ? OR `date` LIKE ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo 'Failed to prepare the statement';
    exit;
}

$searchValue = "%$value%";
$stmt->bind_param("ss", $searchValue, $searchValue);  // Bind the search value twice for both title and date
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    echo 'Error executing the query';
    exit;
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Encode output to prevent XSS
        $title = htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8');
        $details = htmlspecialchars($row['details'], ENT_QUOTES, 'UTF-8');
        $other = htmlspecialchars($row['other'], ENT_QUOTES, 'UTF-8');
        $date = htmlspecialchars($row['date'], ENT_QUOTES, 'UTF-8');
        $advance = htmlspecialchars($row['advance'], ENT_QUOTES, 'UTF-8');

        echo '<div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <div class="d-flex align-items-center">
            <div class="ms-3">
              <p class="fw-bold mb-1">'.$row["title"].'</p>
              <p class="text-muted mb-0">'.$row["details"].'</p>
              <p class="fw-bold mb-1"><i class="fas fa-user"></i>  Client :  '.$row["other"].'</p>
            </div>
          </div>
          <span class="badge rounded-pill badge-success">'.$row["date"].'</span>
        </div>
      </div>
      <div
        class="card-footer border-0 bg-body-tertiary p-2 d-flex justify-content-around"
      >
        <a
          class="btn btn-link m-0 text-reset"
          href="#"
          id="advance"
          role="button"
          data-ripple-color="primary"
          data-mdb-ripple-init
          >Advance '.$row["advance"].' <i class="fas fa-indian-rupee-sign"></i></a>
        <a
          class="btn btn-link m-0 text-reset"
          data-bs-toggle="modal" 
          data-bs-target="#staticBackdrop"
          id="payment"
          data-id="'.$row["booking_id"].'"
          role="button"
          data-ripple-color="primary"
          data-mdb-ripple-init
          >Payments<i class="fab fa-amazon-pay"></i></a>
      </div>
    </div>';
    }
} else {
    echo 'No results found';
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
