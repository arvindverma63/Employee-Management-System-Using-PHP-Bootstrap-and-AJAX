<?php
include("../database/config.php");

// Get the input data
$input = file_get_contents("php://input");
$data = json_decode($input, true);

$response = array();
if (isset($data["id"])) {
    $id = $data["id"];

    // Prepare and execute the DELETE statement for user_details
    $query1 = $conn->prepare("DELETE FROM user_details WHERE u_id = ?");
    $query1->bind_param("s", $id);
    $result1 = $query1->execute();

    // Prepare and execute the DELETE statement for users
    $query2 = $conn->prepare("DELETE FROM users WHERE u_id = ?");
    $query2->bind_param("s", $id);
    $result2 = $query2->execute();

    if ($result1 && $result2) {
        $response = array("data" => "deleted");
    } else {
        $response = array("data" => "error", "message" => "Failed to delete records");
    }
} else {
    $response = array("data" => "error", "message" => "ID not provided");
}

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
