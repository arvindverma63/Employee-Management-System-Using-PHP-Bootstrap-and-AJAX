<?php
// Include the database configuration file
include("../database/config.php");

// Get the JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

$response = array();

// Check if the connection was successful
if ($conn === false) {
    $response = array("data" => "error", "message" => "Database connection failed");
    echo json_encode($response);
    exit;
}

// Check if all required fields are present
$requiredFields = ["total_amount", "advance", "date", "status", "client", "title", "id", "receiver"];
foreach ($requiredFields as $field) {
    if (!isset($data[$field])) {
        $response = array("data" => "error", "message" => "Missing required field: $field");
        echo json_encode($response);
        exit;
    }
}

// Extract data from JSON and sanitize
$total_amount = mysqli_real_escape_string($conn, $data["total_amount"]);
$advance = mysqli_real_escape_string($conn, $data["advance"]);
$date = mysqli_real_escape_string($conn, $data["date"]);
$status = mysqli_real_escape_string($conn, $data["status"]);
$client = mysqli_real_escape_string($conn, $data["client"]);
$title = mysqli_real_escape_string($conn, $data["title"]);
$sender = mysqli_real_escape_string($conn, $data["id"]);
$receiver = mysqli_real_escape_string($conn, $data["receiver"]);

// Prepare the SQL query using prepared statements
$query = "INSERT INTO payments (`title`, `amount`, `advance`, `date`, `status`, `client`, `sender`, `reciever`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $query);

if ($stmt === false) {
    $response = array("data" => "error", "message" => "Statement preparation failed: " . mysqli_error($conn));
    echo json_encode($response);
    exit;
}

// Bind parameters
mysqli_stmt_bind_param($stmt, 'ssssssss', $title, $total_amount, $advance, $date, $status, $client, $sender, $receiver);

// Execute the statement
$result = mysqli_stmt_execute($stmt);

// Check if the query was successful
if ($result) {
    $response = array("data" => "success");
} else {
    $response = array("data" => "error", "message" => "Execution failed: " . mysqli_stmt_error($stmt));
}

// Close the statement
mysqli_stmt_close($stmt);

// Close the database connection
mysqli_close($conn);

// Return JSON response
echo json_encode($response);
?>
