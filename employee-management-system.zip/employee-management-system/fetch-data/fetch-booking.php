<?php include("../database/config.php");
  $query = "SELECT * FROM bookings ORDER BY s_no DESC";
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result)>0){
  	while($row = mysqli_fetch_assoc($result)){
  		echo '<div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <div class="d-flex align-items-center">
            <div class="ms-3">
              <p class="fw-bold mb-1">'.$row["title"].'</p>
              <p class="text-muted mb-0">'.$row["details"].'</p>
              <p class="fw-bold mb-1"><i class="fas fa-user"></i>  Client :  '.$row["other"].'</p>
            </div>
          </div>
          <span class="badge rounded-pill badge-success">'.$row["date"].'</span>
        </div>
      </div>
      <div
        class="card-footer border-0 bg-body-tertiary p-2 d-flex justify-content-around"
      >
        <a
          class="btn btn-link m-0 text-reset"
          href="#"
          id="advance"
          role="button"
          data-ripple-color="primary"
          data-mdb-ripple-init
          >Advance '.$row["advance"].' <i class="fas fa-indian-rupee-sign"></i></a>
        <a
          class="btn btn-link m-0 text-reset"
          data-bs-toggle="modal" 
          data-bs-target="#staticBackdrop"
          id="payment"
          data-id="'.$row["booking_id"].'"
          role="button"
          data-ripple-color="primary"
          data-mdb-ripple-init
          >Payments<i class="fab fa-amazon-pay"></i></a>
      </div>
    </div>';
  	}
  }else{
      echo "<center>No Booking Now</center>";
  }
?>