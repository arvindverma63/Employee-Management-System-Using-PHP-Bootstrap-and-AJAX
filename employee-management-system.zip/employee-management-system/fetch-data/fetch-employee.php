<?php 
  include("../database/config.php");
  $query = "SELECT * FROM user_details WHERE role = 'shop' OR role = 'employee'";
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
      echo '<li class="list-group-item d-flex justify-content-between align-items-center">
              <div class="d-flex align-items-center">
                <img src="fetch-data/'.$row["image"].'" alt="" style="width: 45px; height: 45px" class="rounded-circle" />
                <div class="ms-3">
                  <p class="fw-bold mb-1" id="name">'.$row["fname"].' '.$row["lname"].'  ('.$row["role"].')</p>
                  <p class="text-muted mb-0" id="email">'.$row["email"].'</p>
                </div>

              </div>
              <button type="button" id="edit-user" data-id="'.$row["u_id"].'" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop1">
                       Edit
                     </button>
            </li>';
    }
  }
?>
