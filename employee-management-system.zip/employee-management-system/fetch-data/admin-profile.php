<?php 
  include("../database/config.php");
  $input = file_get_contents("php://input");
  $data = json_decode($input,true);
  $id = $data["id"];
  $query = "SELECT * FROM user_details WHERE u_id = '$id'";
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result)>0){
  	while($row = mysqli_fetch_assoc($result)){
  		echo '<div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <img src="fetch-data/'.$row["image"].'"
              class="rounded-circle img-fluid" style="width: 150px;">
            <h5 class="my-3">'.$row["fname"].' '.$row["lname"].'</h5>
            <p class="text-muted mb-1">'.$row["role"].'</p>
            <p class="text-muted mb-4">'.$row["address"].'</p>
            <div class="d-flex justify-content-center mb-2">
              <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary">Edit</button>
              <input type="file" class="btn btn-outline-primary ms-1" id="uploadImage" style="display: none;" />
<label for="uploadImage" class="btn btn-outline-primary ms-1" data-mdb-button-init data-mdb-ripple-init>Upload Image</label>


            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["fname"].' '.$row["lname"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["email"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Phone</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["phone"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Address</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["address"].'</p>
              </div>
            </div>
          </div>
        </div>
        
    </div>
  </div>';
  	}
  }
?>