<?php
error_reporting(0);
include("../database/config.php"); // Make sure config.php has your database connection details
// Get JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Extract email and password from JSON data
$email = $data["email"];
$password = $data["password"];

$response = array();

// Use prepared statements to prevent SQL injection
$query = "SELECT * FROM users WHERE `email` = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 1) {
    // User found, now verify password
    $user = $result->fetch_assoc();
    $hashedPassword = $user['password'];

    if (password_verify($password, $hashedPassword)) {
        // Password is correct
        $role = $user['role'];
         session_start();
        $_SESSION['uid'] = $user['u_id'];
        if($role == "owner") {
            $response = array("data" => "owner");
        } elseif($role == "shop") {
            $response = array("data"=> "shop");
        } elseif($role == "employee") {
            $response = array("data" => "employee");
        }
    } else {
        // Password is incorrect
        $response = array("data" => "error", "message" => "Incorrect password");
    }
} else {
    // User not found
    $response = array("data" => "error", "message" => "User not found");
}

echo json_encode($response);
?>
