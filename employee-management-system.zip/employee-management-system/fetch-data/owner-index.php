<?php
   include("../database/config.php");

   // Correct SQL queries
   $query1 = "SELECT * FROM user_details WHERE role = 'employee'";
   $query2 = "SELECT * FROM user_details WHERE role = 'shop'";

   // Execute the first query
   $result1 = mysqli_query($conn, $query1);

   // Check for errors in the query
   if (!$result1) {
       die('Invalid query: ' . mysqli_error($conn));
   }

   // Get the number of rows
   $row1 = mysqli_num_rows($result1);

   echo '<div class="card">
  <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
    <img src="images/employee.png" class="img-fluid" id="image1" />
    <a href="#!">
      <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
    </a>
  </div>
  <div class="card-body">
    <h5 class="card-title">Employees</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the cards content.</p>
    <a href="#!" class="btn btn-primary" data-mdb-ripple-init>' . $row1 . '</a>
  </div>
</div>';

   // Execute the second query
   $result2 = mysqli_query($conn, $query2);

   // Check for errors in the query
   if (!$result2) {
       die('Invalid query: ' . mysqli_error($conn));
   }

   // Get the number of rows
   $row2 = mysqli_num_rows($result2);

   echo '<div class="card">
  <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
    <img src="images/employees.png" class="img-fluid" id="image2" />
    <a href="#!">
      <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
    </a>
  </div>
  <div class="card-body">
    <h5 class="card-title">Shops</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card s content.</p>
    <a href="#!" class="btn btn-primary" data-mdb-ripple-init>' . $row2 . '</a>
  </div>
</div>';

?>
