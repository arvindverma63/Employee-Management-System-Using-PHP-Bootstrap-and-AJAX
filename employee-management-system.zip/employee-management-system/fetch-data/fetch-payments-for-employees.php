<?php
include("../database/config.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT * FROM payments";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Escape output to prevent XSS
        $title = htmlspecialchars($row["title"]);
        $client = htmlspecialchars($row["client"]);
        $amount = htmlspecialchars($row["amount"]);
        $advance = htmlspecialchars($row["advance"]);
        $status = htmlspecialchars($row["status"]);
        $date = htmlspecialchars($row["date"]); // Format the date if necessary

        echo '<div class="card">
                <div class="card-header">' . $title . '</div>
                <div class="card-body">
                    <h5 class="card-title">Client: ' . $client . '</h5>
                    <h5 class="card-title">Amount: ' . $amount . '</h5>
                    <h5 class="card-title">Advance Amount: ' . $advance . '</h5>
                    <a href="#" class="btn btn-primary" data-mdb-ripple-init>' . $status . '</a>
                    <h5 class="card-title mt-2">Date: ' . $date . '</h5>
                </div>
              </div>';
    }
} else {
    echo "<center>No record found</center>";
}

mysqli_close($conn); // Close the database connection
?>
