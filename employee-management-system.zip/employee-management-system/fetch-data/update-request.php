<?php
  include("../database/config.php");
  
  if (isset($_GET['s_no'])) {
    $s_no = $_GET['s_no'];
    
    // Prepare the SQL statement
    $stmt = $conn->prepare("UPDATE payments SET request = ? WHERE s_no = ?");
    $request = 'accepted';
    $stmt->bind_param("si", $request, $s_no);
    
    if ($stmt->execute()) {
      echo "Update successful.";
    } else {
      echo "Error updating record: " . $stmt->error;
    }
    
    $stmt->close();
  } else {
    echo "Serial number not provided.";
  }
?>
