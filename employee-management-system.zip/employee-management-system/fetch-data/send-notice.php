<?php
include("../database/config.php");

$input = file_get_contents("php://input");
$data = json_decode($input, true);
$response = array();

$receiver = $data["receiver"]; // Corrected variable name
$title = mysqli_real_escape_string($conn, $data["title"]); // Escape strings to prevent SQL injection
$message = mysqli_real_escape_string($conn, $data["message"]); // Escape strings to prevent SQL injection

$query = "INSERT INTO notices (`title`, `reciever`, `body`, `date`) VALUES ('$title', '$receiver', '$message', NOW())"; // Use NOW() to insert current date and time
$result = mysqli_query($conn, $query);

if ($result) {
    $response = array("data" => "success");
} else {
    $response = array("data" => "error"); // Optionally handle error response
}

echo json_encode($response);
?>
