<?php 
include("../database/config.php");

$response = array();
$u_id = "U" . time();
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$role = $_POST['role'];
$email = $_POST['email'];
$address = $_POST['address'];
$phone = $_POST['phone'];


 $file_name = $_FILES['image']['name'];
 $tempname = $_FILES['image']['tmp_name'];
  $folder = "upload/".$file_name;

 move_uploaded_file($tempname, $folder);


$password = password_hash($phone, PASSWORD_DEFAULT);

$query1 = "INSERT INTO users(`u_id`,`email`,`password`,`role`) VALUES ('$u_id','$email','$password','$role')";
$query2 = "INSERT INTO user_details(`fname`,`lname`,`role`,`email`,`phone`,`address`,`u_id`,`image`) VALUES ('$fname','$lname','$role','$email','$phone','$address','$u_id','$folder')";

$result1 = mysqli_query($conn, $query1);
$result2 = mysqli_query($conn, $query2);

if ($result1 && $result2) {
    $response = array("data" => "success");
} else {
    $response = array("data" => "error");
}

echo json_encode($response);
?>
