<?php 
include("../database/config.php");

// Get the raw POST data
$input = file_get_contents("php://input");
// Decode the JSON data
$data = json_decode($input, true);
$response = array();

// Extract the value from the decoded JSON data
$value = $data["editUserId"];
// Use prepared statements to prevent SQL injection
$query = "SELECT * FROM user_details WHERE u_id=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $value); // Assuming 'u_id' is a string, use 'i' for integer
$stmt->execute();
$result = $stmt->get_result();

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Fetch rows one by one and add them to the response array
    while ($row = $result->fetch_assoc()) {
        $response[] = $row;
    }
}

// Encode the response array to JSON and send it back
echo json_encode($response);
?>
