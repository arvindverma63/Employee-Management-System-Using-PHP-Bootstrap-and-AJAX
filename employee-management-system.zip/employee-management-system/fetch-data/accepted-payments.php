<?php
include("../database/config.php");

// Fetch all payments
$query = "SELECT * FROM payments";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Fetch sender details using a prepared statement
        $stmt = mysqli_prepare($conn, "SELECT * FROM user_details WHERE u_id = ?");
        mysqli_stmt_bind_param($stmt, 's', $row["sender"]);
        mysqli_stmt_execute($stmt);
        $result2 = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result2) > 0) {
            $sender = mysqli_fetch_assoc($result2);
            $senderName = $sender["fname"] . " " . $sender["lname"];
        } else {
            $senderName = "Unknown Sender";
        }

        // Display the payment details along with sender's name
        if($row["request"] == "accepted"){
            echo '<div class="card">
                <div class="card-header">' . htmlspecialchars($row["title"], ENT_QUOTES, 'UTF-8') . '</div>
                <div class="card-body">
                    <h5 class="card-title">Client: ' . htmlspecialchars($row["client"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Amount: ' . htmlspecialchars($row["amount"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Advance Amount: ' . htmlspecialchars($row["advance"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Sender Name: ' . htmlspecialchars($senderName, ENT_QUOTES, 'UTF-8') . '</h5>
                    <a href="#" class="btn btn-primary" data-mdb-ripple-init>' . htmlspecialchars($row["status"], ENT_QUOTES, 'UTF-8') . '</a>
                    <h5 class="card-title mt-2">Date: ' . htmlspecialchars($row["date"], ENT_QUOTES, 'UTF-8') . '</h5>
                </div>
              </div>';

        }
        
        mysqli_stmt_close($stmt);
    }
} else {
    echo "<center>No Payments Now</center>";
}

mysqli_close($conn);
?>
