<?php
include("../database/config.php");

// Get the raw input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Check for JSON decoding errors
if (json_last_error() !== JSON_ERROR_NONE) {
    echo 'Invalid JSON input';
    exit;
}

// Check if the value key exists in the data array
if (!isset($data['value'])) {
    echo 'Value key missing in input';
    exit;
}

$value = $data['value'];

// Use prepared statements to prevent SQL injection
$query = "SELECT * FROM payments WHERE title LIKE ?";
$stmt = $conn->prepare($query);
$searchValue = "%$value%";
$stmt->bind_param("s", $searchValue);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Encode output to prevent XSS
        $title = htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8');

        echo '<div class="card">
                <div class="card-header">PAYMENT REQUEST FROM '.$other.'</div>
                <div class="card-body">
                    
                    <h5 class="card-title">Amount: ' . htmlspecialchars($row["amount"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Advance Amount: ' . htmlspecialchars($row["advance"], ENT_QUOTES, 'UTF-8') . '</h5>
                    <h5 class="card-title">Sender Name: ' . htmlspecialchars($senderName, ENT_QUOTES, 'UTF-8') . '</h5>
                    <a href="fetch-data/update-request.php?s_no='.$row["s_no"].'" class="btn btn-success" data-mdb-ripple-init> Click to Accept Request</a>
                    <h5 class="card-title mt-2">Date: ' . htmlspecialchars($row["date"], ENT_QUOTES, 'UTF-8') . '</h5>
                </div>
              </div><hr>';
    }
} else {
    echo 'No results found';
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
