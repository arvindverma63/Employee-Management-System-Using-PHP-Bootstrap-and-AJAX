<?php include("header.php")?>
<body>
   <?php include("navbar.php")  ?>
   <style type="text/css">
   	.container{
       margin-top: 3%;
   	}
    #update-payment{
        width: 100%;
    }
    #payment-form{
        width: 100%;
    }
    #booking-payments{
        font-size: 14px;
    }
    .input-group{
        margin-top: 5%;
        margin-left: 10%;
        margin-right: 10%;
        width: 80%;
        

    }
   </style>

   <div class="input-group">
  <div class="form-outline" data-mdb-input-init>
    <input type="search" id="value" class="form-control" />
    <label class="form-label" for="form1">Search</label>
  </div>
  <button type="button" class="btn btn-primary" data-mdb-ripple-init>
    <i class="fas fa-search"></i>
  </button>
</div>
   <!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" id="update-payment" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Update Payments
  </button>
  <ul class="dropdown-menu" id="payment-form">
    <form style="margin-left: 10%; margin-right: 10%;">
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div data-mdb-input-init class="form-group">
    <label class="form-label" for="form6Example3">Booking_id</label>
    <input type="text" id="ubooking_id" class="form-control" disabled />
  </div>
  <div data-mdb-input-init class="form-group">
    <label class="form-label" for="form6Example3">Payment Tittle</label>
    <input type="text" id="utitle" class="form-control" />
  </div>
  


  <!-- Text input -->
  <div data-mdb-input-init class="form-group">
    <label class="form-label" for="form6Example3">Total Amount</label>
    <input type="text" id="utotal_amount" class="form-control" />
      </div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-group">
    <label class="form-label" for="form6Example4">Advance Amount</label>
    <input type="text" id="uadvance" class="form-control" />
  </div>

  <div class="form-floating">
  <select class="form-select" id="ustatus" aria-label="Floating label select example">
    <option value="success">Success</option>
    <option value="pending">Pending</option>
  </select>
  <label for="floatingSelect">Works with selects</label>
</div>

  <!-- Email input -->
  <div data-mdb-input-init class="form-group">
    <input type="date" id="udate" class="form-control" />
    <!-- <label class="form-label" for="form6Example5">Date</label> -->
  </div>

  <!-- Number input -->
  <!-- <div data-mdb-input-init class="form-outline mb-4">
    <input type="number" id="form6Example6" class="form-control" />
    <label class="form-label" for="form6Example6">Phone</label>
  </div> -->
</form>
<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id="update-submit" class="btn btn-primary">Re-Payment</button>
      </div>
  </ul>
</div>
     <div id="booking-payments"></div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Understood</button> -->
      </div>
    </div>
  </div>
</div>
   <div class="container" id="container">
   	<!-- Button trigger modal -->


    
   </div>
</body>
<!-- <script type="text/javascript">


  
   document.getElementById("searche").addEventListener("keyup", function () {
    var value = document.getElementById("searche").value;
    fetch("fetch-data/search-booking.php", {
        method: "POST",
        body: JSON.stringify({ value: value }),
        headers: {
            "Content-Type": "application/json"
        }
    }).then(response => response.text()) // Change to response.text() if the response is HTML
    .then((data) => {
        document.getElementById("container").innerHTML = data;
    }).catch((error) => {
        console.error('Error:', error);
    });
});

</script> -->
<script>
    fetch("fetch-data/fetch-booking.php", {
  method: "POST"
})
.then(response => {
  if (!response.ok) {
    throw new Error("Network response was not ok " + response.statusText);

  }
  return response.text();

})
.then(data => {
  document.getElementById("container").innerHTML = data;


   document.getElementById("payment").addEventListener("click", function() {
    var button = document.getElementById("payment").getAttribute("data-id");
      document.getElementById("ubooking_id").value = button;
});



})
.catch(error => {
  console.error("There was a problem with the fetch operation:", error);
});

document.getElementById("update-submit").addEventListener("click", function() {
    var booking_id = document.getElementById("ubooking_id").value;
    var title = document.getElementById("utitle").value;
    var total_amount = document.getElementById("utotal_amount").value;
    var advance = document.getElementById("uadvance").value;
    var status = document.getElementById("ustatus").value;
    var date = document.getElementById("udate").value;

    var payload = {
        booking_id: booking_id,
        title: title,
        total_amount: total_amount,
        advance: advance,
        status: status,
        date: date
    };

    fetch("fetch-data/update-payments.php", {
        method: "POST",
        body: JSON.stringify(payload),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
        window.location.href = "booking.php";
        // Add code to update the UI or notify the user of success
    })
    .catch(error => {
        console.error('Error:', error);
        // Add code to notify the user of the error
    });
});

var booking_id = document.getElementById("ubooking_id");
fetch("fetch-data/fetch-booking-payments.php",{
    method: "POST",
    body: JSON.stringify({booking_id: booking_id}),
    headers: {
        "Content-Type": "application/json"
    }
}).then(response=>response.text())
.then((data)=>{
    document.getElementById("booking-payments").innerHTML = data;

})

document.getElementById("value").addEventListener("keyup", function() {
    const value = this.value;  // Get the value from the input field
    fetch("fetch-data/search-booking.php", {
        method: "POST",
        body: JSON.stringify({ value: value }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();  // Assuming the PHP script returns HTML, not JSON
    })
    .then((data) => {
        document.getElementById("container").innerHTML = data;
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
});


</script>