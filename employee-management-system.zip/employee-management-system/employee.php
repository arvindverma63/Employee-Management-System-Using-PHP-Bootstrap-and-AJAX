<?php include("header.php")?>
<body>
	<?php include("navbar.php")?>
	<style type="text/css">
		.shop-emplyee{
			margin-top: 2%;
			margin-left: 10%;
			margin-right: 10%;
			border-radius: 15px;
		}
		#add{
			width: 80%;
			margin-left: 10%;
			margin-top: 5%;
		}
    @media (max-width: 700px){
      #name{
        font-size: 13px;
      }
      #email{
        font-size: 10px;
      }
      
    }
	</style>
	

<!-- Button trigger modal -->
<button type="button" id="add" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Add Employee
</button>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div class="row mb-4">
    <div class="col">
      <div class="form-outline" data-mdb-input-init>
        <input type="text" id="fname" class="form-control" />
        <label class="form-label" for="form6Example1">First name</label>
      </div>
    </div>
    <div class="col">
      <div data-mdb-input-init class="form-outline">
        <input type="text" id="lname" class="form-control" />
        <label class="form-label" for="form6Example2">Last name</label>
      </div>
    </div>
  </div>

  <!-- Text input -->
    <div class="form-floating">
  <select class="form-select" id="role" aria-label="Floating label select example">
    <option selected>Select Employee Type</option>
    <option value="employee">Employee</option>
    <!-- <option value="owner">owner</option> -->
    <option value="shop">Shop-Employee</option>
  </select>
  <label for="floatingSelect">Works with selects</label>
</div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="address" class="form-control" />
    <label class="form-label" for="form6Example4">Address</label>
  </div>

  <!-- Email input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="email" id="email" class="form-control" />
    <label class="form-label" for="form6Example5">Email</label>
  </div>

  <!-- Number input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="number" id="phone" class="form-control" />
    <label class="form-label" for="form6Example6">Phone</label>
  </div>


  <!-- Message input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <form id="myForm">
    <label class="form-label" for="customFile">Image</label>
<input type="file" class="form-control" id="image" />
</form>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
      </div>
    </div>
  </div>
</div>


<div class="shop-emplyee border-0 p-4 shadow">
		<ul class="list-group list-group-light" id="emp">
  
</ul>
<!-- Button trigger modal -->


	</div>

  <!-- Modal 2 -->
<div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Edit Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" id="editEmployeeForm">
          <div data-mdb-input-init class="form-outline mb-4">
    <label class="form-label" for="form6Example4">Id</label>
    <input type="text" id="eid" class="form-control" disabled/>
    
  </div>
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div class="row mb-4">
    <div class="col">
      <div data-mdb-input-init class="form-outline">
        <label class="form-label" for="form6Example1">First name</label>
        <input type="text" id="efname" class="form-control" />
        
      </div>
    </div>
    <div class="col">
      <div data-mdb-input-init class="form-outline">
        <label class="form-label" for="form6Example2">Last name</label>
        <input type="text" id="elname" class="form-control" />
        
      </div>
    </div>
  </div>

  <!-- Text input -->
    <div class="form-floating">
  <select class="form-select" id="erole" aria-label="Floating label select example">
    <option selected>Select Employee Type</option>
    <option value="employee">Employee</option>
    <!-- <option value="owner">owner</option> -->
    <option value="shop">Shop-Employee</option>
  </select>
  <label for="floatingSelect">Works with selects</label>
</div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <label class="form-label" for="form6Example4">Address</label>
    <input type="text" id="eaddress" class="form-control" />
    
  </div>

  <!-- Email input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <label class="form-label" for="form6Example5">Email</label>
    <input type="email" id="eemail" class="form-control" />
    
  </div>

  <!-- Number input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <label class="form-label" for="form6Example6">Phone</label>
    <input type="number" id="ephone" class="form-control" />
    
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="delete">Delete</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="Edit">Update</button>
      </div>
    </div>
  </form>
  <script type="text/javascript">
    document.getElementById('editEmployeeForm').addEventListener('submit', function(event) {
      event.preventDefault();

      const efname = document.getElementById('efname').value;
      const elname = document.getElementById('elname').value;
      const eemail = document.getElementById('eemail').value;
      const ephone = document.getElementById('ephone').value;
      const eaddress = document.getElementById('eaddress').value;
      const erole = document.getElementById('erole').value;
      const eid = document.getElementById('eid').value;

      fetch('fetch-data/edit-employee.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          efname: efname,
          elname: elname,
          eemail: eemail,
          ephone: ephone,
          eaddress: eaddress,
          erole: erole,
          eid: eid
        })
      })
      .then(response => response.json())
      .then(data => {
        alert(data.message);
        window.location.href = "employee.php";
      })
      .catch(error => {
        console.error('Fetch Error:', error);
      });
    });
      </script>
  </div>
</div>

</body>

<script type="text/javascript">
   
document.addEventListener("DOMContentLoaded", function() {
    var editUserId; // Variable to store the data-id value

    // Fetch employee data and display it
    fetch("fetch-data/fetch-employee.php")
        .then(response => response.text())
        .then((data) => {
            document.getElementById("emp").innerHTML = data;

            // Add event listener to the "edit-user" buttons
            document.querySelectorAll("#edit-user").forEach(button => {
                button.addEventListener("click", function() {
                    editUserId = this.getAttribute("data-id"); // Store the data-id value in the variable
                    console.log(editUserId);
                    // You can now use the editUserId variable here or outside this function
                    fetch("fetch-data/fetch-employee-for-edit.php", {
                       method: "post",
                       body: JSON.stringify({editUserId: editUserId}), // Corrected
                       headers: { // Corrected
                           "Content-Type" : "application/json"
                       }
                          })
                          .then((response) => response.json())
                          .then((data) => {
                            document.getElementById("eid").value = data[0]["u_id"];
                            document.getElementById("efname").value = data[0]["fname"];
                            document.getElementById("elname").value = data[0]["lname"];
                            document.getElementById("ephone").value = data[0]["phone"];
                            document.getElementById("eemail").value = data[0]["email"];
                            document.getElementById("eaddress").value = data[0]["address"];
                            document.getElementById("erole").value = data[0]["role"];
                            var delete_button = document.getElementById("delete");
                            delete_button.dataset.id = data[0]["u_id"];

                            console.log(data);
                          });

                });

            });
        })
        .catch(error => console.error("Error fetching employee data:", error));

    // Add event listener to the "submit" button
    document.getElementById("submit").addEventListener("click", function(e) {
        e.preventDefault(); // Prevent the default form submission
        
        const formData = new FormData();

        formData.append("fname", document.getElementById("fname").value);
        formData.append("lname", document.getElementById("lname").value);
        formData.append("role", document.getElementById("role").value);
        formData.append("address", document.getElementById("address").value);
        formData.append("email", document.getElementById("email").value);
        formData.append("phone", document.getElementById("phone").value);
        
        // Append the image file to the same formData object
        const image = document.getElementById("image").files[0];
        formData.append("image", image);

        // Append the editUserId value to the formData if needed
        // formData.append("editUserId", editUserId);

        // Send form data to server
        fetch("fetch-data/insert-employee-data.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then((data) => {
            if (data["data"] === "success") {
                window.location.href = "employee.php";
            } else {
                console.error("Error:", data);
            }
        })
        .catch(error => console.error("Error:", error));
    });

    // You can access the editUserId variable here or outside the event listener function
});

document.getElementById("delete").addEventListener("click", function() {
    const id = this.getAttribute('data-id');

    fetch("fetch-data/delete-employee.php", {
        method: "POST",
        body: JSON.stringify({ id: id }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data["data"] === "deleted") {
            alert("Deleted successfully");
            window.location.href = "employee.php";
            // Optionally, you can add code here to remove the deleted item from the DOM or refresh the list
        } else {
            alert("Error deleting the record");
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("An error occurred while deleting the record");
    });
});


</script>
</html>