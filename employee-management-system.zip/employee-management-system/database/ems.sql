-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2024 at 04:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dukan`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `s_no` int(11) NOT NULL,
  `details` varchar(100) NOT NULL,
  `total_amount` varchar(10) NOT NULL,
  `advance` varchar(10) NOT NULL,
  `date` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `other` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `booking_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`s_no`, `details`, `total_amount`, `advance`, `date`, `status`, `other`, `title`, `booking_id`) VALUES
(6, 'hello word', '234', '23', '2024-05-22', 'success', 'w dfsf', 'dj', 'B1716182087');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `s_no` int(11) NOT NULL,
  `reciever` varchar(30) NOT NULL,
  `title` varchar(300) NOT NULL,
  `body` varchar(3000) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`s_no`, `reciever`, `title`, `body`, `date`) VALUES
(1, '', 'hello', 'world', '2024-05-14 06:59:17');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `s_no` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `client` varchar(200) NOT NULL,
  `amount` double NOT NULL,
  `advance` double NOT NULL,
  `status` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `sender` varchar(30) NOT NULL,
  `reciever` varchar(30) NOT NULL,
  `request` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`s_no`, `title`, `client`, `amount`, `advance`, `status`, `date`, `sender`, `reciever`, `request`) VALUES
(2, 'dj', 'add', 76, 87, 'success', '2024-05-23', '', '', 'accepted'),
(3, 'dj', 'ajay', 2324, 423, 'success', '2024-05-20', '', '', 'accepted'),
(4, '', '', 0, 0, 'Select Payment Type', '', 'U1715487767', 'ewr3', '');

-- --------------------------------------------------------

--
-- Table structure for table `update_bookings`
--

CREATE TABLE `update_bookings` (
  `s_no` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `advance` varchar(200) NOT NULL,
  `total_amount` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `booking_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `update_bookings`
--

INSERT INTO `update_bookings` (`s_no`, `title`, `advance`, `total_amount`, `status`, `date`, `booking_id`) VALUES
(1, 'dj', '234', '45', 'pending', '21-05-2024', 'B1716182087');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `s_no` int(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `u_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`s_no`, `email`, `password`, `role`, `u_id`) VALUES
(993627, 'aman@gmail.com', '$2y$10$kgzP2a/MZkQ4XHLdevAKsOqG6mYFNHT2ZEdhQXmI8PMM6jxZBJj0K', 'shop', 'U1715484974'),
(993629, 'aman@gmail.com', '$2y$10$rqIiDq7iabqZYu5FVTERaeo8P8v7XC3O7zyhCpU9347oo34VNed7a', 'shop', 'U1715485547'),
(993631, 'owner@gmail.com', '$2y$10$tphhN6lByaOkAJ5tBPsDJez9ljyRk5iR94atQzlxk9gtCHyObNwSK', 'owner', 'U1715487767'),
(993633, 'ajay@gmail.com', '$2y$10$4HnJ2u3CWv/fMfIj.AhwOOAcw/Ta79X2/KzioQpVGLN4x/POUaOce', 'employee', 'U1715493145'),
(993634, 'akash@gmail.com', '$2y$10$QJKm9qlV4KgPgDtiqzNCnearrmbT.ub8kfQX5DdQCc3/JIYh8oDY6', 'employee', 'U1715580446'),
(993635, 'shop@gmail.com', '$2y$10$4Re3tCYKQdBeSu1RCfK22e9bpwarnGUhJ78RS3XNJ3aaZKcCg7M3S', 'shop', 'U1716009169');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `s_no` int(11) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `role` varchar(30) NOT NULL,
  `u_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`s_no`, `fname`, `lname`, `email`, `phone`, `address`, `image`, `role`, `u_id`) VALUES
(27, 'aman', 'vishwakarma', 'aman@gmail.com', '894561252', 'jkdfjkal sfjd kf', 'upload/pexels-fox-1172675.jpg', 'shop', 'U1715485547'),
(29, 'owne', 'kumar', 'owner@gmail.com', '54622', 'kjfd jkjskj ', 'upload/1.jpg', 'owner', 'U1715487767'),
(31, 'ajay', 'kumar', 'ajay@gmail.com', '89653241', 'hello world', 'upload/IMG-20240425-WA0006.jpg', 'employee', 'U1715493145'),
(32, 'akash', 'bajpai', 'akash@gmail.com', '985623147', '73 d karrahi jp school kanpur', 'upload/Chrysanthemum.jpg', 'employee', 'U1715580446'),
(33, 'shop', 'employee', 'shop@gmail.com', '123', 'madarhsip', 'upload/0c91e879-5270-458b-aef8-3ce9c0d50390-removebg-preview.png', 'shop', 'U1716009169');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `update_bookings`
--
ALTER TABLE `update_bookings`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `update_bookings`
--
ALTER TABLE `update_bookings`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `s_no` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=993637;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
