<?php 
 $server = "localhost";
 $user = "root";
 $password = "";
 $db = "dukan";
 
 $conn = mysqli_connect($server,$user,$password,$db);

 if(!$conn){
     header("Location: ./index.php");
 }
 ?>