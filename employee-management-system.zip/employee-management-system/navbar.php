

<div class="navigation">
<nav class="navbar navbar-expand-lg bg-dark bg-gradient">
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="#">EMS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="owner.php">Home</a>
        </li>
             
             <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="employee.php">Employees</a>
        </li>
                
                <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            WorkSpace
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="booking.php">Booking</a></li>
            <li><a class="dropdown-item" href="payment.php">Payments</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="notice.php">Notice</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="fetch-data/logout.php">Logout</a>
        </li>
        
      </ul>
      <!-- <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" id="searc" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> -->
    </div>
  </div>
</nav>
	</div>
  <style>
    .navbar-nav .nav-link {
      color: white; /* Ensure text color is visible on white background */
    }
    .navbar-nav .nav-link.active {
      color: #e9ecef; /* Slightly different background for active links */
    }
    .navbar-nav .dropdown-menu {
      color: white; /* Change dropdown menu background to white */
    }
    .navbar-nav .dropdown-menu .dropdown-item {
      color: black; /* Ensure dropdown items text color is visible */
    }
    .navbar-nav .dropdown-menu .dropdown-item:hover {
      color: #f8f9fa; /* Slight hover effect */
    }
    .navbar-toggler {
      border-color: rgba(255, 255, 255, 0.1); /* Optional: change border color to match */
    }
    .navbar-toggler-icon {
      background-image: url('data:image/svg+xml;charset=utf8,%3Csvg viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg"%3E%3Cpath stroke="rgba%28255, 255, 255, 1%29" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M4 7h22M4 15h22M4 23h22"/%3E%3C/svg%3E');
    }
  </style>