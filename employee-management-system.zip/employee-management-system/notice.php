<?php include("header.php")?>
<body>
  <?php include("navbar.php")?>
  <style type="text/css">
  .text-muted{
    margin-left: 2%;
    margin-bottom: 2%;
  }
 .card{
  margin-left: 10%;
  margin-right: 10%;
  margin-top: 3%;
 }
#Download{
   height: 50px;
   width: 150px;
   background-color: lightblue;
   color: black;
   border: none;
   border-radius: 10px;
}
 .notice-send{
  margin-left: 10%;
  margin-top: 2%;
 }
 #class{
  margin-top: 3%;
 }
 .form-label{
  margin-top: 3%;
 }
 #delete{
  background-color: white;
  margin-left: 90%;
  border: none;
 }
#sends{
        width: 90%;
        margin-top: 2%;
        background-color: green;
        border-color: none;
    }
/*#else{*/
/*        margin-top: 15%;*/
/*    }*/
.nothing{
    height: 10%;
    width: 15%;
    margin-left: 37%;
    margin-top: 5%;
    
}
.nothing img{
    background-size: cover;
    background-position: center;
    height: 400px;
    width: 400px;
}
@media only screen and (max-width: 700px) {
    #time {
        margin-left: 5%;
        font-size: 10px;
    }
    #delete{
        margin-left: 70%;
    }
    .to{
        font-size: 15px;
    }
    .card-title{
        font-size: 18px;
    }
    #else{
        margin-top: 15%;
    }
    #sends{
        width: 90%;
        margin-top: 4%;
    }
    .nothing{
    height: 10%;
    width: 15%;
    margin-left: 10%;
    
}
.nothing img{
    background-size: cover;
    background-position: center;
    height: 300px;
    width: 300px;
}

}


    </style>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Notice</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <select class="form-select" id="role" aria-label="Default select example" required>
             <option selected>----SELECT Reciever----</option>
             <option value="">All</option>
             <option value="se">Shop-Employee</option>
             <option value="e">Employee</option>
          </select>
         <label for="exampleDatepicker1" class="form-label">Title</label>
          <input type="text" class="form-control" id="title"  required />

          <div class="form-outline">
        <label class="form-label" for="textAreaExample">Message</label>
      <textarea class="form-control" id="message" required></textarea>
    </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="send">Send </button>
      </div>
    </div>
  </div>
</div>
      <div class="notice-send">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" id="sends">
  Send Notice <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor" style="color: white;">
  <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path>
</svg>

</button>        
      </div>

<?php 
include("database/config.php");
$sql_query = "SELECT * FROM notices ORDER BY s_no DESC";
$result = mysqli_query($conn, $sql_query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Sanitize output
        $title = htmlspecialchars($row['title']);
        $body = htmlspecialchars($row['body']);
        $role = htmlspecialchars($row['reciever']);
        $class = htmlspecialchars($row['date']);

        if($role==''){
            $role='All';
        }
        
        echo "<div class='card'>
                <div class='card-header'>
                  Notice
                </div>
                <div class='card-body'>
                  <h5 class='card-title'>Title: $title </h5>
                  <h5 class='to'>To : $role"; 
        if($role=='employee'){
            echo "Employees";
        } 
        else{
            echo "Shop Employees";
        }
        echo "</h5>
                  <p class='card-text'>Body: $body</p>";
        echo "<button type='button' class='btn btn-danger delete' data-id='".$row['s_no']."' id='delete'><img src='uploads/trash.svg' id='icon'></button>
                </div>
                <small class='text-muted' id='time'><b>".$row['date']."</b></small>
              </div>";                               
    }
} 
else {
    echo "
    <div class='nothing'><img src='uploads/thumb.gif'></div>
    <center id='else'>No notices found</center>";
}
?>


</body>
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.delete').forEach(function(button) {
        button.addEventListener('click', function() {
            var result = window.confirm("Are you sure you want to delete this notice?");
            if (result) {
                var noticeId = button.getAttribute('data-id');
                fetch('fetch-data/notice-delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'noticeId=' + encodeURIComponent(noticeId)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    console.log(data);
                    location.reload();
                    // Handle success response here if needed
                })
                .catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
                });
            } else {
                console.log("Not deleted");
            }
        });
    });
});

  </script>
<script type="text/javascript">
   document.getElementById("send").addEventListener("click", function() {
    var receiver = document.getElementById("role").value; // Corrected variable name
    var title = document.getElementById("title").value;
    var message = document.getElementById("message").value;

    fetch("fetch-data/send-notice.php", {
        method: "POST",
        body: JSON.stringify({ receiver: receiver, title: title, message: message }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if(data["data"]=="success"){
            window.location.href = "notice.php";
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

</script>
</html>