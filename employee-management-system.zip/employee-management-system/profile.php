<?php include("header.php")?>

<body>
  <?php include("navbar.php")?>
  <style type="text/css">
    .profiles{
      margin-top: 2%;
    }
  </style>
  <!-- Button trigger modal -->

  <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editEmployeeModalLabel">Edit Employee</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="editEmployeeForm">
              <div class="mb-3">
                <label for="efname" class="form-label">Id</label>
                <input type="text" class="form-control" id="eid" disabled required>
              </div>
              <div class="mb-3">
                <label for="efname" class="form-label">First Name</label>
                <input type="text" class="form-control" id="efname" required>
              </div>
              <div class="mb-3">
                <label for="elname" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="elname" required>
              </div>
              <div class="mb-3">
                <label for="eemail" class="form-label">Email</label>
                <input type="email" class="form-control" id="eemail" required>
              </div>
              <div class="mb-3">
                <label for="ephone" class="form-label">Phone</label>
                <input type="text" class="form-control" id="ephone" required>
              </div>
              <div class="mb-3">
                <label for="eaddress" class="form-label">Address</label>
                <input type="text" class="form-control" id="eaddress" required>
              </div>
              <input type="hidden" id="eid" value="123"> <!-- Replace with dynamic ID -->
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <script>
    document.getElementById('editEmployeeForm').addEventListener('submit', function(event) {
      event.preventDefault();

      const efname = document.getElementById('efname').value;
      const elname = document.getElementById('elname').value;
      const eemail = document.getElementById('eemail').value;
      const ephone = document.getElementById('ephone').value;
      const eaddress = document.getElementById('eaddress').value;
      const eid = document.getElementById('eid').value;

      fetch('fetch-data/edit-owner.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          efname: efname,
          elname: elname,
          eemail: eemail,
          ephone: ephone,
          eaddress: eaddress,
          eid: eid
        })
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        alert(data.message);
        if (data.status === 'success') {
          var modal = bootstrap.Modal.getInstance(document.getElementById('editEmployeeModal'));
          modal.hide();
          window.location.href = "profile.php";
        }
      })
      .catch(error => {
        console.error('Fetch Error:', error);
      });
    });
  </script>

          </div>
        </div>
      </div>
    </div>



  <div class="profiles">
    <!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Update(Change) Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
        <label class="form-label" for="customFile">Default file input example</label>
<input type="file" class="form-control" id="image" />
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id="uploadImage" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal2 -->
    <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Change Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="">
          <input type="hidden" name="id" value="<?php echo htmlspecialchars($id, ENT_QUOTES, 'UTF-8'); ?>">
          <div class="form-group">
            <label for="currentPassword">Current Password</label>
            <input type="password" class="form-control" id="currentPassword" name="current" placeholder="Current Password">
          </div>
          <div class="form-group">
            <label for="newPassword">New Password</label>
            <input type="password" class="form-control" id="newPassword" name="new" placeholder="New Password">
          </div>
          <div class="form-group">
            <label for="confirmPassword">Confirm New Password</label>
            <input type="password" class="form-control" id="confirmPassword" name="repeat" placeholder="Re-type New Password">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>

<?php
include("database/config.php");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $response = array();
    
    // Sanitize and validate inputs
    $currentPassword = $_POST['current'];
    $newPassword = $_POST['new'];
    $confirmNewPassword = $_POST['repeat'];
    
    if (!empty($currentPassword) && !empty($newPassword) && !empty($confirmNewPassword)) {
        if ($newPassword === $confirmNewPassword) {
            $query = "SELECT password FROM users WHERE u_id=?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $hashedPassword = $row['password'];
                
                if (password_verify($currentPassword, $hashedPassword)) {
                    $newHashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $updateQuery = "UPDATE users SET password=? WHERE u_id=?";
                    $updateStmt = $conn->prepare($updateQuery);
                    $updateStmt->bind_param("ss", $newHashedPassword, $id);
                    
                    if ($updateStmt->execute()) {
                        echo "<script>alert('Password Updated Successfully');</script>";
                    } else {
                        echo "<script>alert('Unable to update password');</script>";
                    }
                } else {
                    echo "<script>alert('Incorrect current password');</script>";
                }
            } else {
                echo "<script>alert('User not found');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('New password and confirm password do not match');</script>";
        }
    } else {
        echo "<script>alert('All fields are required');</script>";
    }
    $conn->close();
}
?>

    
    <section style="background-color: #eee;">
  <div class="container py-5">
    <div class="row">
      <div class="col">
        <nav aria-label="breadcrumb" class="bg-body-tertiary rounded-3 p-3 mb-4">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item active" aria-current="page">User Profile</li>
          </ol>
        </nav>
      </div>
    </div>

   
   <?php 
  include("database/config.php");
  $query = "SELECT * FROM user_details WHERE u_id = '$id'";
  $result = mysqli_query($conn,$query);
  if(mysqli_num_rows($result)>0){
    while($row = mysqli_fetch_assoc($result)){
      echo '<div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <img src="fetch-data/'.$row["image"].'"
              class="rounded-circle img-fluid" style="width: 150px;">
            <h5 class="my-3">'.$row["fname"].' '.$row["lname"].'</h5>
            <p class="text-muted mb-1">'.$row["role"].'</p>
            <p class="text-muted mb-4">'.$row["address"].'</p>
            <div class="d-flex justify-content-center mb-2">

              <button type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editEmployeeModal">Edit</button>
<button type="button" id="add" class="btn btn-outline-primary ms-1" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Upload-Image
</button>


            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["fname"].' '.$row["lname"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["email"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Phone</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["phone"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Address</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">'.$row["address"].'</p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Password</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><button type="button" id="add" class="btn btn-outline-primary ms-1" data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
  Reset Password
</button></p>
              </div>
            </div>


            
          </div>
        </div>
        
    </div>
  </div>';
    }
  }
?>
</section>
  </div>
 <?php echo "<script>var id = '".$id."';</script>"; ?>
</body>
<script>
    document.getElementById("uploadImage").addEventListener("click", function() {
      const formData = new FormData();
      const imageInput = document.getElementById("image");
      const image = imageInput.files[0];

      if (image) {
        formData.append("image", image);
        formData.append("id", id);

        fetch("fetch-data/update-image.php", {
          method: "POST",
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          console.log(data);
          if (data["data"] === "success") {
            window.location.href = "profile.php";
          } else {
            console.error('Error:', data.error);
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
      } else {
        console.error('No image selected');
      }
    });

    fetch("fetch-data/fetch-employee-for-edit.php", {
                       method: "post",
                       body: JSON.stringify({editUserId: id}), // Corrected
                       headers: { // Corrected
                           "Content-Type" : "application/json"
                       }
                          })
                          .then((response) => response.json())
                          .then((data) => {
                            document.getElementById("eid").value = data[0]["u_id"];
                            document.getElementById("efname").value = data[0]["fname"];
                            document.getElementById("elname").value = data[0]["lname"];
                            document.getElementById("ephone").value = data[0]["phone"];
                            document.getElementById("eemail").value = data[0]["email"];
                            document.getElementById("eaddress").value = data[0]["address"];
                            console.log(data);
                          });
  </script>
</html>