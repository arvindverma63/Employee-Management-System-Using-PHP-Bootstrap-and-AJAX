<?php include("header.php")?>
<body>
	
	<?php include("navbar.php")?>
<div
  class="bg-image p-5 text-center shadow-1-strong rounded mb-5 text-white mt-4"
  style="background-image: url('images/index-bg.jpg');"
>
  <h1 class="mb-3 h2">Notice</h1>

  <p>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repellendus praesentium
    labore accusamus sequi, voluptate debitis tenetur in deleniti possimus modi voluptatum
    neque maiores dolorem unde? Aut dolorum quod excepturi fugit.
  </p>
</div>
<!-- Jumbotron -->
<?php include("footer.php")?>
</body>
</html>