<?php include("header.php")?>
<body>
   <?php include("navbar.php")  ?>
   <style type="text/css">
      .shop-emplyee{
         margin-top: 2%;
         margin-left: 10%;
         margin-right: 10%;
         border-radius: 15px;
      }
      #add{
         width: 80%;
         margin-left: 10%;
         margin-top: 5%;
      }
      .booking-list{
        margin-left: 10%;
        margin-right: 10%;
        margin-top: 4%;
      }
      @media (max-width: 700px){
        #bookins{
        font-size: 15px;
      }
      #advance{
        font-size: 12px;
      }
      #payment{
        font-size: 12px;
      }
      }
   </style>
   
<!-- Button trigger modal -->
<button type="button" id="add" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Add Booking
</button>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Add Booking</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="title" class="form-control" />
    <label class="form-label" for="form6Example3">Order Tittle</label>
  </div>
  <div class="row mb-4">
    <div class="col">
      <div data-mdb-input-init class="form-outline">
        <input type="text" id="details" class="form-control" />
        <label class="form-label" for="form6Example1">Details</label>
      </div>
    </div>
    <!-- <div class="col">
      <div data-mdb-input-init class="form-outline">
        <input type="text" id="form6Example2" class="form-control" />
        <label class="form-label" for="form6Example2">Last name</label>
      </div>
    </div> -->
  </div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="total_amount" class="form-control" />
    <label class="form-label" for="form6Example3">Total Amount</label>
  </div>

  <!-- Text input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <input type="text" id="advance" class="form-control" />
    <label class="form-label" for="form6Example4">Advance Amount</label>
  </div>

  <div class="form-floating">
  <select class="form-select" id="status" aria-label="Floating label select example">
    <option selected>Select Payment Type</option>
    <option value="success">Success</option>
    <option value="pending">Pending</option>
  </select>
  <label for="floatingSelect">Works with selects</label>
</div>

  <!-- Email input -->
  <div data-mdb-input-init class="form-outline mb-4 mt-4">
    <input type="date" id="date" class="form-control" />
    <label class="form-label" for="form6Example5">Date</label>
  </div>

  <!-- Number input -->
  <!-- <div data-mdb-input-init class="form-outline mb-4">
    <input type="number" id="form6Example6" class="form-control" />
    <label class="form-label" for="form6Example6">Phone</label>
  </div> -->

  <!-- Message input -->
  <div data-mdb-input-init class="form-outline mb-4">
    <textarea class="form-control" id="other" rows="4"></textarea>
    <label class="form-label" for="form6Example7">Client Details : </label>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>

<div class="booking-list">
  <div class="row" id="bookings-list">
  <div class="col-xl-6 mb-4">
    
  </div>
  </div>
</div>
</div>

</body>

<script type="text/javascript">
  document.getElementById("submit").addEventListener("click",function(){
    var title = document.getElementById("title").value;
    var details = document.getElementById("details").value;
    var total_amount = document.getElementById("total_amount").value;
    var advance = document.getElementById("advance").value;
    var status = document.getElementById("status").value;
    var date = document.getElementById("date").value;
    var other = document.getElementById("other").value;

    var obj = {
      title: title,
      details: details,
      total_amount: total_amount,
      advance: advance,
      status: status,
      date: date,
      other: other
    }

    fetch("../fetch-data/submit-booking.php",{
      method: "post",
      body: JSON.stringify(obj),
      headers: {
        "Content-Type" : "application/json"
      }
    }).then(response=>response.json())
    .then((data)=>{
      if(data["data"]=="success"){
           window.location.href = "booking.php";
      }
    })
  })

  fetch("../fetch-data/fetch-booking.php")
  .then(response=>response.text())
  .then((data)=>{
    document.getElementById("bookings-list").innerHTML = data;
  })
</script>